#include <iostream>
#include "chefe.hpp"
#include "funcionario.hpp"
#include "menu.hpp"
#include "pessoa.hpp"
#include "vendas.hpp"
#include "modoGerente.hpp"
#include "horario.hpp"

using namespace std;


/*
LOGIN E SENHA PARA ACESSAR COMO CHEFE
USER: joao
PASSWORD: 1234
*/


int main()
{
    Menu novo;
    //chama o menu inicial
    novo.menuInicial();
    return 0;
}
